#!/bin/bash

/ctf/qemu-mipsel /ctf/mipscode_level1 2>/dev/null