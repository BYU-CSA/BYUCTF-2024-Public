#!/bin/bash

/ctf/qemu-mipsel /ctf/mipscode_level2 2>/dev/null