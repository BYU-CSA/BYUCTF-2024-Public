#!/bin/bash

/ctf/qemu-mipsel /ctf/token 2>/dev/null